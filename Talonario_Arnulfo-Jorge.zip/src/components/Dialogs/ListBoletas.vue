<script setup>
import { ref, defineProps } from "vue";

const props = defineProps({
  dataBoletas: Array,
  actualColor: Object,
});

const pagination = ref({
        rowsPerPage: 6,
      })

const filter = ref("");


const columns = [
  {
    name: "name",
    required: true,
    label: "Nombre",
    align: "left",
    field: (row) => row.name,
    sortable: true,
    style: "margin : 0; padding: 0",
  },
  {
    name: "telefono",
    required: true,
    label: "Telefono",
    align: "left",
    field: (row) => row.telefono,
    sortable: true,
    style: "margin : 0; padding: 0",
  },
  {
    name: "direcion",
    required: true,
    label: "Direcion",
    align: "left",
    field: (row) => row.direccion,
    sortable: true,
    style: "margin : 0; padding: 0",
  },
  {
    name: "boletas",
    required: true,
    label: "Boletas",
    align: "left",
    //mostrar todos los numeros de las boletas almacenados en el array y concatenado un - para separarlos
    field: (row) => row.boletas.map((item) => item.numero).join(" - "),
    sortable: true,
    style: "margin : 0; padding: 0",
  },
];


</script>

<template>
  <q-card class="my-card " style="width: 700px; max-width: 80vw">
    <q-card-section style="padding: 0px;">
      <div >
        <q-table
          grid
          title="LISTADO DE BOLETAS"
          :rows="dataBoletas"
          :columns="columns"
          row-key="name"
          :filter="filter"
          hide-header
          v-model:pagination="pagination"
          :rows-per-page-options="[0]"
          no-data-label="No hay datos para mostrar"
          no-results-label="El cliente no existe"
        >

          <template v-slot:top-right>
            <q-input
              borderless
              dense
              debounce="300"
              v-model="filter"
              rounded outlined
              label="Buscar"
              bg-color="white"
            >
              <template v-slot:append>
                <q-icon name="search" />
              </template>
            </q-input>
          </template>
          
        </q-table>
      </div>
    </q-card-section>


    <q-separator />

    <q-card-actions align="center" >
      <q-btn v-close-popup class="colorBtn" label="Cerrar" />
    </q-card-actions>
  </q-card>
</template>


<style>
.q-table__top,
  thead tr:first-child th{
    /* bg color is important for th; just specify one */
    background-color: v-bind("actualColor.color_fondo_header") !important;
    color: v-bind("actualColor.color_title_talonario") !important;
  }

  .colorBtn{
    color: v-bind("actualColor.color_title_talonario") !important;
    background-color: v-bind("actualColor.color_fondo_header") !important;
  }


.q-table__grid-item-card{
  box-shadow: 0px 0px 10px 0px rgb(136, 136, 136);
}


</style>