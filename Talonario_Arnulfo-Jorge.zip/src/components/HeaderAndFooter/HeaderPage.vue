<template>
    <q-header elevated class="color-header">
        <q-toolbar>
          <div class="row full-width q-py-xs justify-center flex">
            <div class="col-11 text-center ">
              <q-toolbar-title class=" color-title title">TALONARIO</q-toolbar-title>
            </div>
          </div>
  
        </q-toolbar>
      </q-header>
</template>

<style>


.title{
    font-size: 3.2em;
    font-weight: 600;
    color: #fff;
    text-shadow: 2px 2px 2px #000;
}


</style> 