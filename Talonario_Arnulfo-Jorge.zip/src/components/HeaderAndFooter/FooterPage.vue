<template>
<q-footer elevated class="color-header">
    <q-toolbar>
      <q-toolbar-title class="row justify-center">
        <div class="col-12 text-footer color-title text-center">
          
          © Copyraight 2023 - Todos los derechos reservados

        </div>


      </q-toolbar-title>
    </q-toolbar>
  </q-footer>


      
</template>

<style>
.text-footer{
font-size: 16px;
}
</style>